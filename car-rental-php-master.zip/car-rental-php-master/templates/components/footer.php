

<footer class="footer">
    <div class="container text-center" style="padding: 10px;">
        <span>© carjack 2017-18 &nbsp;</span>
        <img src="/images/car-logo.svg" />
    </div>
</footer>

</body>
</html>