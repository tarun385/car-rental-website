<img class="img-responsive" style="margin: 0 auto;" src="../images/404-robo.svg"/>
<div class="text-center">
    <p class="lead">We could not find what you were looking for!</p>

    <a href="/"><button class="btn btn-primary">Home</button></a>
</div>