<div class="panel panel-default" style="background-color: #ff333b">
    <div class="panel-body text-center">
        <h3 class="lead" style="color: #ffccc6">You are logged out!</h3>
    </div>
</div>