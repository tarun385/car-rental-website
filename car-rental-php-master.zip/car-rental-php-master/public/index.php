<?php

require_once('../classes/Router.php');

Router::route();
